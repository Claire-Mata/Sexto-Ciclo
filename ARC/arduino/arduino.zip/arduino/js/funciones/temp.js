var dataTable ="";
$(document).ready(function() {
	$('.datepick').datepicker({
		format: "yyyy-mm-dd",
		language: "es",
		autoclose: true,
	})
	generar();
});
function generar(){
	fechai=$("#fecha_inicio").val();
	fechaf=$("#fecha_fin").val();
	dataTable = $('#editable2').DataTable().destroy()
	dataTable = $('#editable2').DataTable( {
			"pageLength": 50,
			"order":[[ 0, 'desc' ]],
			"processing": true,
			"serverSide": true,
			"ajax":{
					url :"admin_temp_dt.php?fechai="+fechai+"&fechaf="+fechaf, // json datasource
					error: function(){  // error handling
						$(".editable2-error").html("");
						$("#editable2").append('<tbody class="editable2_grid-error"><tr><th colspan="3">No se encontró información segun busqueda </th></tr></tbody>');
						$("#editable2_processing").css("display","none");
						$( ".editable2-error" ).remove();
						}
					},
		    "language": {
		        "url": "js/funciones/Spanish.json"
		        },
		    "pagingType": "full_numbers"
				} );

		dataTable.ajax.reload()

}
$(document).on("click", "#btnMostrar", function(event) {
	generar();
});
