<div class="footer">


                <strong>Temperatura almacenada arduino <?php echo date("Y");?>
            </div>
        </div>

        </div>
        </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
	<script src="js/plugins/datapicker/moment.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>


    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>
     <!-- Jvectormap -->
    <script src="js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- Jquery Validate -->
    <script src="js/plugins/validate/jquery.validate.min.js"></script>
    <script src="js/plugins/iCheck/icheck.min.js"></script>
    <!--/var/www/html_public/template/js/plugins/toastr -->
    <script src="js/plugins/toastr/toastr.min.js"></script>


    <!-- Data Tables -->
   <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
   <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
   <script src="js/plugins/dataTables/dataTables.responsive.js"></script>
   <script src="js/plugins/dataTables/dataTables.tableTools.min.js"></script>


    <!-- Flot -->
   <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/jquery.flot.symbol.js"></script>
    <script src="js/plugins/flot/curvedLines.js"></script>

    <!-- Peity -->
    <script src="js/plugins/peity/jquery.peity.min.js"></script>
  
    <!-- ChartJS-->
    <script src="js/plugins/chartJs/Chart.min.js"></script>

    <!-- iCheck -->
    <script src="js/plugins/iCheck/icheck.min.js"></script>
    <!-- spinedit -->
    <script src="js/plugins/spinedit/spinedit.js"></script>

    <!--select2 -->
    <script src='js/plugins/select2/select2.js'></script>
    <!--switchery -->
    <script src='js/plugins/switchery/switchery.js'></script>
     <!--summernote -->
    <script src='js/plugins/summernote/summernote.min.js'></script>
    <!--sortable -->
	<script src='js/plugins/sortable/jquery-sortable.js'></script>
    <script src='js/plugins/upload_file/fileinput.js'></script>
    <script src='js/plugins/upload_file/fileinput_locale_es.js'></script>
	<!--numeric -->
	<script src='js/plugins/numeric/jquery.numeric.js'></script>
	<!--datepicker -->
	<script src='js/plugins/datapicker/bootstrap-datepicker.js'></script>
	<!--autocomplete bootstrap3 -->
	<script src='js/plugins/typehead/bootstrap3-typeahead.js'></script>
	<!--jasny-->
	 <script src='js/plugins/jasny/jasny-bootstrap.min.js'></script>
	<!-- Sweet alert -->
    <script src="js/plugins/sweetalert/sweetalert.min.js"></script>


    <!-- Functions creted by us for post messages with toastr and clean forms  -->
    <script src="js/funciones/functions_messages_clean.js"></script>
    <script type="text/javascript">
    window.setInterval(function() {
      var el=document.createElement('img');
      el.src='sessionRenew.php?rand='+Math.random();
      el.style.opacity=.01;
      el.style.width=1;
      el.style.height=1;
      el.onload=function() {
        document.body.removeChild(el);
      }
      document.body.appendChild(el);
    }, 60000);
    </script>


</body>

</html>
