<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=!empty($_PAGE['title']) ? $_PAGE['title'] . ' - ' : null;?>SISTEMA DE GESTION DE PROCESOS MUNICIPALES</title>
<?=!empty($_PAGE['links']) ? $_PAGE['links'] : null;?>
</head>
<body id="page-top" class="md-skin fixed-sidebar fixed-navbar pace-done" landing-scrollspy="" ng-controller="MainCtrl as main">