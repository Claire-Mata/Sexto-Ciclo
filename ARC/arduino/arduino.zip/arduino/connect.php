<?php
$host = "localhost";
$user = "root";
$password = "Admin$2021";
$db = "arduino";


  date_default_timezone_set('America/El_Salvador');
	$conexion = mysqli_connect("$host","$user","$password","$db");
  if (mysqli_connect_errno()){
		echo "Error en conexión MySQL: " . mysqli_connect_error();
	}

function _query($sql_string){
	global $conexion;
	$query=mysqli_query($conexion,$sql_string);
	return $query;
}
// Begin functions queries

function _fetch_array($sql_string){
	global $conexion;
	$fetched = mysqli_fetch_array($sql_string,MYSQLI_BOTH);
	return $fetched;
}


function _fetch_row($sql_string){
	global $conexion;
	$fetched = mysqli_fetch_row($sql_string);
	return $fetched;
}

function _num_rows($sql_string){
	global $conexion;
  $rows = mysqli_num_rows($sql_string);
	return $rows;
}
function _insert_id(){
	global $conexion;
	$value = mysqli_insert_id($conexion);
	return $value;
}
//funcion real escape string
function _real_escape($sql_string){
	global $conexion;
	$query=mysqli_real_escape_string($conexion,$sql_string);
	return $query;
}
// End functions queries

function _insert($table_name, $form_data){
	_query("SET NAMES 'utf8'");
	$form_data2=array();
	$variable='';
	// retrieve the keys of the array (column titles)
	$fields = array_keys ( $form_data );
	// join as string fields and variables to insert
	$fieldss = implode ( ',', $fields );
	foreach($form_data as $variable){
		$var1=preg_match('/\x{27}/u', $variable);
		$var2=preg_match('/\x{22}/u', $variable);
  		if($var1==true || $var2==true){
  		 $variable = addslashes($variable);
  		}
		array_push($form_data2,$variable);
    }
    $variables = implode ( "','",$form_data2 );
    // build the query
    $sql = "INSERT INTO " . $table_name . "(" . $fieldss . ")";
    $sql .= "VALUES('" . $variables . "')";
    return _query($sql);
}


function db_close(){
	global $conexion;
	mysqli_close($conexion);
}
// the where clause is left optional incase the user wants to delete every row!
function _delete($table_name, $where_clause='')
{
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add keyword
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // build the query
    $sql = "DELETE FROM ".$table_name.$whereSQL;

    return _query($sql);
}
// again where clause is left optional
function _update($table_name, $form_data, $where_clause=''){
	//codificar la insercion a UTF-8
	_query("SET NAMES 'utf8'");
    // check for optional where clause
    $whereSQL = '';
    $form_data2=array();
	$variable='';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add key word
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // start the actual SQL statement
    $sql = "UPDATE ".$table_name." SET ";
    // loop and build the column /
    $sets = array();
    $k=0;

	foreach($form_data as $index=>$variable){
		$var1=preg_match('/\x{27}/u', $variable);
		$var2=preg_match('/\x{22}/u', $variable);
		if($var1==true || $var2==true){
		 $variable = addslashes($variable);
		}
		$form_data2[$index] = $variable;
    }
    foreach ( $form_data2 as $column => $value ) {
		$sets [] = $column . " = '" . $value . "'";
	}
    $sql .= implode(', ', $sets);
    // append the where statement
    $sql .= $whereSQL;
    // run and return the query result
    return _query($sql);
}

function max_id($field,$table)
{
    $max_id=_query("SELECT MAX($field) FROM $table");
    $row = _fetch_array($max_id);
    $max_record = $row[0];
    return $max_record;
}
function restar_dias($fecha,$dias){
	//formato date('Y-m-j');
	$nuevafecha = strtotime ('-'.$dias.' day' , strtotime ( $fecha ) ) ;
	$nuevafecha = date ( 'Y-m-d' , $nuevafecha );
	return 	$nuevafecha;
}
