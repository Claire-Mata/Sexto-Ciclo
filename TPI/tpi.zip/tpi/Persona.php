<?php
class Persona  
{
    public $nombre;
    public $apellido;
    public $edad;
}

$persona = new Persona;

persona.$nombre="juan";

echo $nombre;