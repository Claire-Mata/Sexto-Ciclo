//calbacks: funciones anonimas
function date(callback) {
    console.log(new Date());
    //esto espera, pausa
    setTimeout(function () {
        let date= new Date();
        callback(date);
    }, 3000); //pasan 3 segundos
}  
function dateNow(myDate) {
    console.log(myDate);
}
date(dateNow);

let XMLHttpRequest= require("xmlhttprequest").XMLHttpRequest;

let myUrl="http://openlibrary.org/api/books?bibkeys=ISBN:0201558025,LCCN:93005405&format=json";
function fetchDate(url, callback) {
     let xhttp = new XMLHttpRequest();
     //sincrono se refiere a que primero tiene que
     //hacer un proceso para ejecutar otro
     //se coloca true para que sea asincrono:  
     xhttp.open("GET", url, true);
     xhttp.onreadystatechange= function (event) {
         //AQUI YA ME TRAE UN EVENTO
         if (xhttp.readyState === 4) {  
             if (xhttp.status === 200) {
                 callback(null, JSON.parse(xhttp.responseText));
             }else{
                const error = new Error("Error: "+ url);
                return callback(error, null);
             }
         }
     };
     xhttp.send();
}

fetchDate(myUrl, function (error, data) {
    //imprimir solo las caracteristicas del objeto
    //cuando los nombres estan compuestos
    if (error) {
        return console.log.error(error);
    }
    //asiiiii
    console.log(data['ISBN:0201558025']);
    //recursividad
    fetchDate(myUrl, function (error2, data2) {
        if (error2) {
            return console.log.error(error2);
        }
        console.log(data2);
    });
});

//promesas
/*const miPromesa = () =>{
    return new Promise((resolve, reject)=>{
        if (true) {
            resolve( "todo salio nice");
        }else{
            reject("Algo salio mal");
        }
    });
};

miPromesa()
.then((response)=>console.log(response))
.catch((err)=> console.log(err));
*/
miPromesa2 = () => {
    return new Promise((resolve, reject)=>{
        if (true) {
            setTimeout(()=>{
                resolve("OK");
            }, 2000);
        }else{
            const err = new Error (":c");
            reject(err);
        }
    });
};
miPromesa2()
.then((response)=>console.log(response))
.catch((err)=>console.log(err));