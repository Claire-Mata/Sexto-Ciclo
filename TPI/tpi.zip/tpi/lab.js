//Alejandra Claire Aguilar Mata AM19089
const prompt = require("prompt-sync")(); 
 
// NOTACION LITERAL 
const Libreria = { 
    nombre: "Los Angeles", 
    direccion: "Av. Roossevelt San Miguel", 
    seccion: [], 
    libros: [], 
    almacenar: function(a) { 
        this.libros.push(a) 
    } 
} 
 
// NOTACION DE CONSTRUCTOR 
function Libro(nombre, autor, genero) { 
    this.nombre = nombre 
    this.autor = autor 
    this.genero = genero 
} 
 
Libro.prototype.leer = function() { 
    console.log(" Leer ") 
} 
Libro.prototype.mostrarInfo = function() { 
    console.log(this.nombre) 
    console.log(this.autor) 
    console.log(this.genero) 
} 
let aux = "S" 
while(aux == "S"){ 
    let nombre = prompt("Ingrese nombre de libro: ") 
    let autor = prompt("Ingrese autor de libro: ") 
    let genero = prompt("Ingrese genero de libro: ") 
    if(genero == "accion" || genero == "aventura"){ 
        let milibro = new Libro(nombre,autor,genero); 
        Libreria.almacenar(milibro); 
    } 
    aux = prompt("Desea seguir? [S/N] ") 
} 
 
console.log(Libreria)