const prompt = require("prompt-sync")(); 
//promesas

function getData() {
    return new Promise((resolve, reject)=>{
    let nombre = prompt("Ingrese nombre: ")
    let apellido = prompt("Ingrese apellido: ")
    let edad = prompt("Ingrese edad: ")
        if (nombre==="ale") {
        resolve( [nombre, apellido,edad]);
        }
    });
}
let data= getData();
data.then(function(mydata){
    let dataPart= mydata[0];
    console.log(dataPart);
});
let XHMLttpRequest= require("xmlhttprequest").XMLHttpRequest;
function getUrl(url) {
    return new Promise((resolve, reject)=>{
        let req= new XHMLttpRequest();
        req.open("GET", url);
        req.onload=function () {
            if (req.status === 200) {
                resolve(JSON.parse(req.responseText));
            }else{
                reject(Error(req.statusText));
            }
        };
        req.onerror= function () {
            reject(Error("Error de red"));
        };
        req.send();
    });
}
let url="http://openlibrary.org/api/books?bibkeys=ISBN:0201558025,LCCN:93005405&format=json";
getUrl(url).then(
    function (response) {
        console.log("exitooo: ", response );
    },
    function error(error) {
        console.log("algo a salido mal", error);
    }
)
//async await
//te devuelve una promesa
function esperar2segundos(x) {
    return new Promise((resolve)=> {
        setTimeout(()=>{
            resolve(x);
        },2000);
    });
}
async function sumar(x) {
    var a= prompt("Ingrese a: ")
    var b = prompt("Ingrese b: ")
    await esperar2segundos(a);
    await esperar2segundos(b);
    return x+parseInt(a)+parseInt(b);
}
sumar(10).then((v)=>{
    console.log(v);
})