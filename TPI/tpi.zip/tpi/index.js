/*const Animal={
    comer: true,
    dormir: true,
    hacerRuido: function () {
        console.log("Estoy haciendo ruido Rawr");
    }
}

  const Perro ={
      //MEJOR PRACTICA
      __proto__: Animal,
    moverCola: true,
    ladrar: function(){
        //si lo dejamos asi dara undefined
       // console.log("guau guau");
       return "guau guau"
    }
  }

  const Persona = {
      nombre: "Alejandra",
      apellido: "Aguilar",
      set nombreCompleto(nombreCompleto){
          [this.nombre, this.apellido]= nombreCompleto.split(" ")
      },
      get nombreCompleto(){
          return `${this.nombre} ${this.apellido}`
      }
  }
  //accedo al proto
  //Persona.__proto__
   //Cambio el proto
  //Persona.__proto__:Animal
  Persona.nombreCompleto = "Carlos Hernandez"
co
  console.log(Persona.nombreCompleto);*/
  //esto lo podemos hacer para que no salga undifined
  //Perro.hacerRuido()
 

  //console.log(Perro.__proto__);
  //PEOR PRACTICA
  /*Perro.__proto__ = Animal

  //cuando imprimo el prototipe, esto es lo que vengo
  //manejando en mi cadena
  //console.log(Perro.__proto__);
  //console.log(Perro.hacerRuido());
  const pitBull ={

  }
//aqui heredo de Perro pero no de Animal
  pitBull.__proto__ = Perro
  console.log(pitBull);
  
  HERREDAR DE CONSTRUCTORES*/

/*function Persona(nombre, apellido){
    this.nombre= nombre,
    this.apellido= apellido
    this.saludar = function(){
        return "Holaaaa"
    }
    this.despedida = function(){
        return "Adiooos"
    }
}
/*Persona.prototype.saludar= function(){
    return "holaaaaaaaa"
}*/

/*function Alumno(carnet) {
    this.carnet= carnet
    this.estudiar= function(){
        console.log("estoy estudiando");
    }
    
}
Alumno.prototype = new Persona()
let Alejandras = new Alumno("AM19089")



Alejandras.saludar();

/*let Alejandra = new Persona("Alejandra" ,"Aguilar")
let Diego = new Persona("Diego", "Herrera")

Persona.prototype.saludar= function(){
    return "holaaaaaaaa"
}
Persona.prototype.despedida= function(){
    return "adioooos"
}

let pedro = new Persona("pedro", "valdez")
console.log(pedro.despedida());
console.log(Diego.despedida());
console.log(Alejandra.despedida());*/
const tienda = {
    nueva: true,
    abierta: true,
    amplia: true,
    muebles: function(){
        return"vendemos muebles"
    },
    musica: function(){
        console.log("vedemos musica buenisima");
    },
    ropa: function(){
        return"vendemos ropa"
    }
}


const musica = {
    cd: true,
    vinilos: true,
    casette: true,
    __proto__: tienda,
    probarSonido: function(){
        console.log("La la laaa")
    },
    nuevos: function(){
        return"musica nueva solo para ti"
    },
    precio: function(){
        return"musica baratisima y de buena calidad"
    }
}
musica.musica()
const generos = {
    tradicional: true,
    cumbia: true,
    alternativa: true,
    __proto__: musica,
    pop: function(){
        console.log("musica pop")
    },
    rock: function(){
        return"musica rock"
    },
    cristiana: function(){
        return"musica cristiana"
    }
}

generos.probarSonido()

