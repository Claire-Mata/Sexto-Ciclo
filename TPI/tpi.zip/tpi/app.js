// TODO
//NOTACION LITERAL <-
/*
Un objeto cualquier y tiene que llevar
un tipo: var, let o const

Con la notacion Literal se puede acceder a cualquier
propiedad o metodo solo contando con el objeto.
const Persona = () => {...}
const Persona = {...}
let Persona = (argumentos) => {...}
*/
const Persona = {
    nombre: "Kim Jong-un",
    edad: 37,
    saludar: function() {
        return "Hola a todos!"
    },
    presentarse: function() {
        console.log("Mi nombre es "+this.nombre)
    }
}

console.log(Persona.saludar())
Persona.presentarse();

/*----------------------------------------------------------------*/

// NOTACION DE CONSTRUCTOR <-
/*
Con la notacion de constructor, entiendo que
son funciones que se definen como objetos:
function Persona(){...}
function Persona(argumentos){...}
// Inmediatamente invocadas
(function Persona(){ ... })();
(function Persona(argumentos){ ... })();
*/
function Gato(nombre,color) {
    this.nombre = nombre
    this.color = color
    this.comer = true
    this.dormir = function(){
        return `*Se duerme* Zzzz Zzzz Zzzz`;
    }
}
let lanzhan = new Gato("Lanzhan","White");
console.log("\n"+lanzhan.nombre)
console.log(lanzhan.dormir())

/*__________________________________________________________________*/

/* 
Nota: Esto de definir los metodos adentro de los objetos (al heredar)
Según entendí es mala practica, más adelante lo hace de la forma correcta
*/

// Herencia con Notacion literal y Notacion de constructor
// 1er metodo
const Animal = { 
    dormir: true,
    comer: function() {
        console.log(" *Procede a comer* ")
    }
}

const Perro = {
    __proto__: Animal, // Hereda
    moverCola: function() {
        console.log(" *Mueve la cola* ")
    }
}

const Pitbull = {
    __proto__: Perro, // Hereda
    nombre: "Dolly",
    jugar: function() {
        return ` *Juega* `;
    }

}
console.log("\n"+Pitbull.nombre+" hace:")
Pitbull.comer()
Pitbull.moverCola()
console.log(Pitbull.jugar())


// 2do metodo
function Person(nombre,apellido){
    this.nombre = nombre,
    this.apellido = apellido,
    this.saludar = function() {
        return "Hola a todos!";
    }
    this.despedida = function() {
        return "Adios";
    }
}
let kevin = new Person();
console.log(kevin.despedida()); //

// Sobrecarga de metodo "despedida"
Person.prototype.saltar = function() {
    return " *Saltando* "
}

function Estudiante(carnet){
    this.carnet = carnet;
}
// Estudiante.prototype = new Person("Diego","Herrera"); // Aqui hereda pero no seria el mas correcto
Estudiante.prototype = Object.create(Person.prototype); // Más correcto


Estudiante.prototype.estudiar = function(){ // Agregué un metodo
    return " Estoy estudiando JS "
}
let diego = new Estudiante("dh190021");

console.log("\nDespues de crear Estudiante:\n"+kevin.saltar()) // Metodo agregado a Person
// console.log(kevin.estudiar()) // Auui da error porque se creó el objeto kevin antes
console.log(diego.saltar())
console.log(diego.estudiar()) // Metodo agregado a Estudiante
Estudiante.prototype.estudiar = function(){ // Agregué un metodo
    return " Estoy estudiando muchas cosas "
}
console.log(diego.estudiar()) // Sobrecarga el metodo (Creo que es una ventaja ya que si esta dentro del objeto no se puede hacer)

/*------------------------------------------------------------------*/
// Luego viene SCOPE Y ENCLOUSURE

// PATTERN FACTORY
/* Al usar el patron factory nos olvidamos de
   de usar la palabra "new"
*/

// MODEL PATRON

