//FORMA INCORRECTA
/*function Gato(){

}


Gato.prototype.hacerRuido = function(){
    return "PRRRRRRRRR"
}

function Angora(){
    this.nombre= "Michi"
}
//otra forma de hacerlo pero puede ser feo
Angora.prototype= Object.create(Gato.prototype)
//esto se hace para que no me sobreescriba en angora
//Angora.prototype= new Gato()

//sobreEscritura de metodo
Angora.prototype.hacerRuido= function(){
    return "Miau"
}
function Criollo(){
    this.nombre="Mincho"
}

let michi = new Angora()
console.log(michi.hacerRuido());

Criollo.prototype = Gato.prototype

let mincho = new Criollo()
console.log(mincho.hacerRuido());
//console.log(Gato.prototype);*/


//PATRON FACTORY, FACTORY PATTERN

/*function Persona(){
    this.nombre="Alejandra"
    this.edad=18
    this.saludar= function(){
        console.log("hiiii");
    }
}
const P1 =Persona()

//si le quitamos el "new" igual podemos
//imprimir las variables
console.log(nombre);

P1.saludar()

//FORMA CORRECTA
//creamos el objeto
const PersonaFactory = (nombre, edad)=>{
    const saludar= ()=> console.log("Holaaaaa <3");
    //desestructuracion
    return {nombre, edad, saludar}
}

const p1= PersonaFactory("Alejandra", 18)
p1.saludar()
console.log( p1.nombre);

DESESTRUCTURACION
devolver todo lo que tenemos a un objeto
const nombre  = "Alejandra"
const apellido= "Aguilar"
const edad = 18

console.log(nombre, apellido, edad);
console.log({nombre, apellido, edad});

//SCOPE :alcance que tiene alguna variable o funcion (global o local)
//Closure: puedo usar las funcionalidades de otras funciones privadas 

convertir todos los caracteres a mayusculas

const functionFacroty = string =>{
    const hacerMayuscula = () =>string.toUpperCase()
    const imprimir = () => console.log(`---${hacerMayuscula()}---`);
    //aqui estoy diciendo que son publicos
    return{imprimir}
}

const pupusas = functionFacroty('pupusas')
//fuera de la funcion no puedo acceder a estos
//imprimir()
//hacerMayuscula()
//como hacerMayuscula ahora 
//es privada asi que no puedo acceder a ella
//pupusas.hacerMayuscula();
pupusas.imprimir();*/

//HERENCIAAA

const Persona = (nombre)=>{
    const decirNombre = ()=> console.log(`mi nombre es ${nombre}`);
    return{decirNombre}

}
const Profesor = (nombre)=>{
    //heredar, escribimos el metodo que quiero
    
    //const{decirNombre}= Persona(nombre)
    //forma mas profecional para heredar:
    const prototype = Persona(nombre)

    mostrarMateria=()=> console.log("TPI");
    return Object.assign({},prototype,{mostrarMateria})
    //return{decirNombre, mostrarMateria}
}
const diego = Profesor("Diego")
diego.decirNombre()
diego.mostrarMateria()

//object.assign(target,fuentes)
//target objeto al cual yo quiero que se le pasen todas 
//las caracteristicas de un objeto a otro
//target donde yo quiero copiar y fuentes de donde los copiare