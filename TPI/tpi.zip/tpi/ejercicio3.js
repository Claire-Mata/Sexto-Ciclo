// IIFE

/*(function mostrarNombre() {
    var nombre = "Alejandra Claire";
    console.log(nombre);
})();

var nombre="aguilar mata";

(function mostrarNombre(nombre) {
   // var nombre = "Alejandra Claire";
    console.log(nombre);
})(nombre);*/
//funcion oculta
const calculadora = (()=>{
    const suma = (a, b)=> a+b;
    const resta = (a, b)=> a-b;
    const multiplicacion = (a, b)=> a*b;
    const division = (a, b)=> a/b;

    function metodoPublico(c,d) {
        return suma(c,d)
    }
    //para hacerlos publicos
    //return{suma, resta}
    return{metodoPublico}
})();

console.log(calculadora.metodoPublico(4,8));

let myArray = [1,2,3,4,5];
let myProducts=[
    {id:1, nombre: "carne", precio:20.99, promoCode: "tpi155"},
    {id:2, nombre: "leche", precio:2.99, promoCode:"" },
    {id:3, nombre: "huevos", precio:4.99,promoCode:""},
    {id:4, nombre: "queso", precio:3.99,promoCode:""},
    {id:5, nombre: "pescado", precio:7.99,promoCode:"tpi155"}
    
]
myArray.forEach((item, index)=>console.log(item));

myProducts.forEach((item, index)=>{
    console.log(item.id, item.nombre, item.precio);
});

let mapeado = myArray.map((item) => item*2);
console.log(mapeado);

//quiero activar promo
//spread operator
//este te modifica algo pero los que no se modifican
//te salen indefinidos
let myProductsPromo= myProducts.map((item) => {
    var cupon = 'tpi155';
    if(item.promoCode===cupon){
        return{
            //modifica o agrega elementos 
            ...item,
            precio: item.precio /2
        };
    }
    else{
        return item;
    }
});

console.log("promociooon");
console.log(myProductsPromo);

console.log("pick your filter");
let myProductsOrigin = myProducts.filter(item=> item.precio<3);

let myProductsD = myProductsPromo.filter(item=> item.precio<5);

console.log(myProductsD);
console.log(myProductsOrigin);


//reduce
//me toma un array y me lo reducira a una condicion que yo
//le establezca
let reduced = myArray.reduce((prev, sig)=>{
    console.log(prev, sig);
    return prev + sig;
//si pongo aqui un numero me lo toma como el numero 
//con el que empezara
},0);
console.log("reduciendoo");
console.log(reduced);
//some, find y no se cual mas :/