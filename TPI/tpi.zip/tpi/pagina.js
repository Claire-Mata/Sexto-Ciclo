

// Pattern Factory
function bodyFactory(){
    
    // Propiedades
    this.body = "body";
    this.header = "header";
    this.footer = "footer";

    // Metodos
    this.todobody = () => {
        document.body = document.createElement(this.body);
    }

    this.todoheader = () => {
        let header = document.createElement("header");
        h1 = document.createElement("h1");
        h1.textContent = "Header";
        header.appendChild(h1);
        document.body.appendChild(header);
    }
    this.todomain = () => {
        let main = document.createElement("main");
        spam = document.createElement("spam");
        spam.textContent = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
        main.appendChild(spam);
        document.body.appendChild(main);
    }
    this.todofooter = () => {
        let footer = document.createElement("footer");
        spam = document.createElement("spam");
        spam.textContent = "footer";
        footer.appendChild(spam);
        document.body.appendChild(footer);
    }
    this.img = () => {
        var img = document.createElement("img");
        img.src = "si.png";
        var src = document.getElementsByTagName("footer");
        src.appendChild(img);
    }

    return {todobody,todoheader,todomain,img,todofooter};
}

// todo
let mibody = bodyFactory();
mibody.todobody();
mibody.todoheader();
mibody.todomain();
mibody.todofooter();
mibody.img();