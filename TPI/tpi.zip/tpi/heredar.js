
//1er metodo

// obj 1
const figura = {
    prop1: true,
    prop2: true,
    prop3: true,
    metodo1: function(){
        console.log("m1, figura")
    },
    metodo2: function(){
        console.log("m2, figura")
    },
    metodo3: function(){
        console.log("m3, figura")
    }
}

// obj 2
const circulo = {
    prop4: true,
    prop5: true,
    prop6: true,
    metodo4: function(){
        console.log("m4, circulo")
    },
    metodo5: function(){
        console.log("m5, circulo")
    },
    metodo6: function(){
        console.log("m6, circulo")
    }
}

// hereda
circulo.__proto__ = figura;

// obj 3
const mini_circulo = {
    prop7: false,
    prop8: false,
    prop9: true,
    metodo7: function(){
        console.log("m7, mini")
    },
    metodo8: function(){
        console.log("m8, mini")
    },
    metodo9: function(){
        console.log("m9, mini")
    }
}

mini_circulo.__proto__ = circulo;

// obj 4
const mini = {
    prop10: false,
    prop11: false,
    prop12: false,
    metodo10: function(){
        console.log("m11, menor")
    },
    metodo11: function(){
        console.log("m12, menor")
    },
    metodo12: function(){
        console.log("m13, menor")
    }
}

mini.__proto__ = mini_circulo;

console.log(figura);
console.log(circulo);
console.log(mini_circulo);
console.log(mini);

//2do metodo


function Animal(pro1,pro2,pro3){
    this.pro1 = pro1;
    this.pro2 = pro2;
    this.pro3 = pro3;
}

Animal.prototype.me1 = function() {
    console.log("me1");
}
Animal.prototype.me2 = function() {
    console.log("me2");
}
Animal.prototype.me3 = function() {
    console.log("me3");
}

function Perro(pro4,pro5,pro6){
    __proto__ = Animal;
    this.pro4 = pro4;
    this.pro5 = pro5;
    this.pro6 = pro6;
}

Perro.prototype.me4 = function() {
    console.log("me4");
}
Perro.prototype.me5 = function() {
    console.log("me5");
}
Perro.prototype.me6 = function() {
    console.log("me6");
}

// Pastor Aleman
function PastorA(pro7,pro8,pro9){
    __proto__ = Perro;
    this.pro7 = pro7;
    this.pro8 = pro8;
    this.pro9 = pro9;
}

PastorA.prototype.me7 = function() {
    console.log("me7");
}
PastorA.prototype.me8 = function() {
    console.log("me8");
}
PastorA.prototype.me9 = function() {
    console.log("me9");
}

// Nombre del Pastor Aleman
function Dogui(pro10,pro11,pro12){
    __proto__ = PastorA;
    this.pro10 = pro10;
    this.pro11 = pro11;
    this.pro12 = pro12;
}

Dogui.prototype.me10 = function() {
    console.log("me10");
}
Dogui.prototype.me11 = function() {
    console.log("me11");
}
Dogui.prototype.me12 = function() {
    console.log("me12");
}

let a = new Animal("1","2","3");
let b = new Perro("4","5","6");
let c = new PastorA("7","8","9");
let d = new Dogui("10","11","12");

console.log(a);
console.log(b);
console.log(c);
console.log(d);