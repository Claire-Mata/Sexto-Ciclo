const head = ()=>{
    const header = ()=> console.log(`<!DOCTYPE html> 
    <html>
    <head>
        <meta charset="UTF-8">
        <title>
            mi primer pagina web
        </title>
    </head>`);
    return{header}

}

const cuerpo = ()=>{
    const prototype = head()

    body=()=> console.log(`<body>
    <h1>hola mundo html</h1>
    </body>`);
    return Object.assign({},prototype,{body})
}

const pie = ()=>{
    const prototype = cuerpo()

    footer=()=> console.log(`</html>`);
    return Object.assign({},prototype,{footer})
}
const pagina1 = pie()
pagina1.header()
pagina1.body()
pagina1.footer()