var url1="";
$(document).ready(function() {
	 url1=$("#url1").val();
	var process=$('#process').val();
   // $("#datos_inmueble").hide()
   $(".select").select2();
	$(".decimal").numeric();
	$('.numeric').numeric();
	$('.integer').numeric(false, function() { alert('Integers only'); this.value = ''; this.focus(); });
	$('.positive').numeric({ negative: false }, function() { alert('No negative values'); this.value = ''; this.focus(); });
	$('.positive-integer').numeric({ decimal: false, negative: false }, function() { alert('Positive integers only'); this.value = ''; this.focus(); });
    $('.decimal-2-places').numeric({ decimalPlaces: 2 }); 
    
   $(".select").select2();
   $(".numeric").numeric();
   $(".decimal").numeric();
   $("#tipo_lugar").select2();
   $("#tipo_lugar").select2({placeholder: "Seleccione un  tipo Lugar",allowClear: true});
   $("#lugar").select2({placeholder: "Primero Seleccione el Contribuyente",allowClear: true});

//$("#crear_cta1").one("click",function(){	
$("#crear_cta1").on("click",function(){		 
   senddata();
});      

   // fin funciones que al activar check de frente oculta/muestra calle y acera


//Autocomplete typeahead
 $("#buscar_contribuyente").typeahead({
	//  contentType: "application/json; charset=utf-8",
	source: function(query, process) {
		$.ajax({
                   url: 'contribuyente_autocomplete.php',
                    type: 'POST',
                    data: 'query=' + query ,
                    dataType: 'JSON',
                    async: true,
                   
                    success: function(data) {
						$("#xcontribuyente").val('');
                        process(data);
						}
                });                
            },
            
           updater: function(selection){
					var data0=selection;
					
						 var data= data0.split(",");
						 var id_data = data[0];
						 var descrip1 =data[1];
						  var descrip2 = data[2];
						$("#id_contribuyente").val(id_data);
						
						$("#xcontribuyente").val(descrip1);
						//agregar_inmueble(id_data);
				}  
				
     
});  
 //fin Autocomplete typeahead  
  
 //Autocomplete typeahead Cuenta
 $("#buscar_cat_cuenta").typeahead({
	//  contentType: "application/json; charset=utf-8",
	source: function(query, process) {
		datastring='proceso=catalogo'+'&query=' + query
		$.ajax({
                   url: 'autocompletes.php',
                    type: 'POST',
                    data: datastring ,
                    dataType: 'JSON',
                    async: true,
                    success: function(data) {
                        process(data);
					}
                });                
            },
           updater: function(selection){
					var data0=selection;
						 var data= data0.split("|");
						 var id_data = data[0];
						 var descrip1 =data[1];
						  var descrip2 = data[2];
						//alert(id_data);
						agregar_cuenta(id_data);
				}  
     
});  
 //fin Autocomplete typeahead   
 
 //seleccionar inmueble inicial
 if(process=='edited'){
 select_inmueble_inicial()
 tabla_cuenta_lista()
}
   
}); //end document ready
//evitar el send del form al darle enter solo con click en el boton
$(document).on("keypress", 'form', function (e) {
    var code = e.keyCode || e.which;
    if (code == 13) {
        e.preventDefault();
        return false;
    }
});

$(document).on("keyup","#serie, #correlativo, #xcontribuyente",function(event){
    		$(this).val($(this).val().toUpperCase());
});

function agregar_inmueble(id_data){
	
//---- SELECT INMUEBLES-----//
// $("#tipo_lugar").change(function(){	
 	$("#lugar *").remove();
 	$("#select2-lugar-container").text("");
 	
 
 	var ajaxdata = { 
 					"process" : "buscar_inmueble",
 					"id_contribuyente": id_data
 				}
	//alert(ajaxdata);
    $.ajax({
      	url:url1,
      	type: "POST",
      	data: ajaxdata,
      	success: function(opciones)
      	{
	      	$("#select2-lugar-container").text("Seleccione un Lugar de la Lista");
	        $("#lugar").html(opciones);
	        $("#lugar").val("");
    	}
    })  
//});
//---- FIN SELECT INMUEBLES -----//
}

$(function (){
	//binding event click for button in modal form
	$(document).on("click", "#btnDelete", function(event) {
		deleted();
	});
	// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) {
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	
	//evento change SELECT INMUEBLES -----//
$("#lugar").change(function(){	
 	var id_inmueble=$("#lugar").val();
	var url1=url1;
	var url2="tabla_inmueble.php";
 	var ajaxdata={ 
 		"process" : "buscar_datos_inmueble",
 		"id_inmueble": id_inmueble
 	}
 	var ajaxdata2= "?process=buscar_datos_inmueble2&id_inmueble="+id_inmueble;

    $.ajax({
      	url:url1,
      	type: "POST",
      	data: ajaxdata,
      	dataType: 'json',
      	success: function(datos)
      	{
			
	        $("#direccion").val(datos.direccion);
	        $("#codigo_catastral").val(datos.codigo_catastral);
    	}
    })  
    
    $("#tabla_inmueble").load(url2+ajaxdata2);			
});
//---- FIN change SELECT INMUEBLES -----//
	
	
	
});	
function tabla_cuenta_lista(){
	var id_cuenta=$("#id_cuenta").val();
	//var url1=url1;
	var url2="tabla_cuenta.php";
 	/*var ajaxdata={ 
 		"process" : "buscar_datos_inmueble",
 		"id_inmueble": id_inmueble
 	}*/
 	var ajaxdata2= "?process=buscar_datos_cuenta&id_cuenta="+id_cuenta;
	/*
    $.ajax({
      	url:url1,
      	type: "POST",
      	data: ajaxdata,
      	dataType: 'json',
      	success: function(datos)
      	{
			
	        $("#direccion").val(datos.direccion);
	        $("#codigo_catastral").val(datos.codigo_catastral);
    	}
    })  
    */
	$(".decimal").numeric();
    $("#accountable2").load(url2+ajaxdata2);	
    $(".numeric").numeric();
	$(".decimal").numeric();
}
function select_inmueble_inicial(){
	var id_inmueble=$("#id_inmueble").val();
	//var url1=url1;
	//var url2="tabla_inmueble.php";
	var url2="tabla_cuenta.php";
 	var ajaxdata={ 
 		"process" : "buscar_datos_inmueble",
 		"id_inmueble": id_inmueble
 	}
 	var ajaxdata2= "?process=buscar_datos_inmueble&id_inmueble="+id_inmueble;

    $.ajax({
      	url:url1,
      	type: "POST",
      	data: ajaxdata,
      	dataType: 'json',
      	success: function(datos)
      	{
			
	        $("#direccion").val(datos.direccion);
	        $("#codigo_catastral").val(datos.codigo_catastral);
    	}
    })  
    
    $("#tabla_inmueble").load(url2+ajaxdata2);	

}
function reload1(){
	location.href = 'admin_cuenta_inmueble.php';	
}
function deleted() {
	var id_inmueble = $('#id_inmueble').val();
	var dataString = 'process=deleted' + '&id_inmueble=' + id_inmueble;
	$.ajax({
		type : "POST",
		url : "borrar_inmueble.php",
		data : dataString,
		dataType : 'json',
		success : function(datax) {
			display_notify(datax.typeinfo, datax.msg);
			
			setInterval("location.reload();", 1000);
			$('#deleteModal').hide(); 
		}
	});
}
// Evento para agregar elementos al grid de cuenta
function agregar_cuenta(id,descrip){
	var dataString = 'process=consultar_cat_cuenta' + '&id_cat=' + id;
	var filas=0;
	$.ajax({
		type : "POST",
		url : url1,
		data : dataString,
		dataType : 'json',
		success : function(data) {
			var codigo_contable=data.codigo_contable;
			var nombre_cuenta=data.nombre_cuenta;
			var valor=data.valor;
			var ab_um=data.ab_um;
			var valor_um=valor +" X " +ab_um
			var id_previo=new Array();
			var filas=0;
			$("#accountable tr").each(function (index) {
			if (index>0){	
			var campo0,campo1,campo2,campo3,campo4,campo5;
			
            $(this).children("td").each(function (index2) {	
           	  switch (index2){
                    case 0: 
						campo0 = $(this).text();
						
						if (campo0!=undefined || campo0!=''){
							id_previo.push(campo0);				
						}						
						break;			
					}
				});	
				filas=filas+1;
				 } //if index>0	
		});
		subtotal=round((1*valor),2);	
		var tr_add = "";
		var val_um="<td><input type='hidden'  id='valor' name='valor' value='"+valor+"'><div>"+valor_um+"</div></td>";
		var accion= "<td class='Delete'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='#'><i class='fa fa-trash'></i></a></td>";	
		var cant="<td><div class='col-sm-4'><input type='text'  class='form-control decimal col-sm-4' id='cant' name='cant' value='1' style='width:60px;'></div></td>";
		tr_add += "<tr id='"+filas+"'>";
		tr_add += '<td>'+id+'</td>';
		tr_add += '<td>'+codigo_contable+'</td>';	
		tr_add += '<td>'+nombre_cuenta+'</td>';	
		tr_add += val_um;
		tr_add +=cant;
		tr_add += "<td id='subtot'>"+subtotal+"</td>";		
		tr_add += accion;
		tr_add += '</tr>';
		
		
		if (filas>1000){
			var typeinfo='Warning';
			var msg='Numero de Filas en Factura excede el maximo permitido !';
			display_notify(typeinfo,msg);		
		}
		else{
			var existe=false;
			var posicion_fila=0;
			$.each(id_previo, function(i,id_ante){
				if(id==id_ante  ){	
					existe=true;
					
				}
			});
			if (existe==false){
				$("#accountable").append(tr_add);
				$(".decimal").numeric();			
			}
			//alert(existe)
			totales();
			}	
		}	//success : function(data) {	
	});	
}	

function round(value, decimals) {
    return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}
function totales(){
	var subtotal=0; total=0; totalcantidad=0;  cantidad=0; total_fin=0;
	var total_dinero=0; total_cantidad=0;  precio_venta=0; precio_venta=0;pv_desc=0;
	var elem1 = '';
	var descripcion='';
	var tipoproducto = '';  tipoprod = '';
	var precio_minimo=0;	 
	var indice=0;	
	var change=false;
	var porc_desc=0;
	var porc_desc_max=0;precio_venta_desc=0;
	var fecha="";
	$("#accountable tr").each(function (index) {
	
		if (index>0){		
           var campo0,campo1, campo2, campo3, campo4, campo5,campo6,campo7;
            $(this).children("td").each(function (index2) {
                switch (index2){
                    case 0: 
						campo0 = $(this).text();						
                        break;                   
                    case 1: 
						campo1 = $(this).text();					
                        break;
                    case 2: 
						campo2 = $(this).text();					
                        break;
                    case 3: 
						campo3 = $(this).find("#valor").val()                    
						if (isNaN(campo3)==false){ 
							valor=parseFloat(campo3);
						}
						else{
							valor=0;
						}
                        break;   
                    case 4:
						campo4= $(this).find("#cant").val();                        
						if (isNaN(campo4)==false){ 
							cantidad=parseFloat(campo4);
						}
						else{
							cantidad=0;
						}
                        break;            
                    case 5: 						
                        campo5= $(this).find("#subtotal").html();
						if (isNaN(campo5)==false){ 
							subtotal=parseFloat(campo5);
						}
						else{
							subtotal=0;
						}                    
                        break; 
                 
                }
                 
            });

            if (isNaN(cantidad)==true){
				cantidad=0;
			}
			
			subtotal=valor*cantidad;
			
            if (isNaN(subtotal)==true){
				subtotal=0;
			}	
            subt=round(subtotal, 2); 
			subtotal_fin=subt.toFixed(2);	
			$(this).find("#subtot").html(subtotal_fin);
            total+=subtotal;
          
          } 
        });
        
        if (isNaN(total)==true){
			total=0;
		}	
        total_dinero=total.toFixed(2);
        total_cantidad=totalcantidad.toFixed(2);
        var porc_fiesta= $('#porc_fiesta').val();
		var tot_fiesta=total_dinero*porc_fiesta;
		var total_fiesta=tot_fiesta.toFixed(2);
		
		total_fin=total+tot_fiesta;
		var total_final=total_fin.toFixed(2);
		
		$('#total_dinero').html("<strong>"+total_dinero+"</strong>");
        $('#totcant').html(total_cantidad);
		$('#totalfactura').val(total_dinero);
		
		$('#text_dinero').html("<strong>TOTAL SERV. $:</strong>");
		$('#total_serv').html("<strong>"+total_dinero+"</strong>");
		$('#total_fiesta').html("<strong>"+total_fiesta+"</strong>");
		$('#total_final').html("<strong>"+total_final+"</strong>");
		
		dataString2='process=total_texto&total='+total_final;
		
		$.ajax({
		type : "POST",
		url : url1,
		data : dataString2,
		dataType : 'json',
		success : function(datax) {
			 $('#totaltexto').html("<strong>"+datax.totaltexto+"</strong>");
		}
	});
		
		
}	
 $(document).on("blur","#cant",function(){
  totales();
})
//Evento que valida el enter a traves del teclado
$(document).on("keydown","#cant", function(event){
	var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode == '13'){
		totales();
	}
})

$(document).on("focusout","#cant",function(){
	totales();
})
$(document).on("keyup","#cant", function(){
	totales();
})
$(document).on("blur","#accountable",function(){
	totales();
})
// Evento que selecciona la fila y la elimina de la tabla
$(document).on("click",".Delete",function(){
	var parent = $(this).parents().get(0);
	$(parent).remove();
	totales();
});	

function senddata(){
    //Get the value from form if edit or insert
	var process=$('#process').val();
	var verificar1=false; verificar2=false;
	var id_contribuyente=$('#id_contribuyente').val();
	if (process=='insert'){
		var id_inmueble=$('#lugar').val();
	}
	if (process=='edited'){
		var id_inmueble=$('#id_inmueble').val();
	}
	//var total=$('#totalfactura').val();
	var total=$('#total_serv').text();
	var fiesta=$('#total_fiesta').text();
	var id_frecuencia=$('#frecuencia1').val();
	var id_cuenta=$("#id_cuenta").val();
	
	if (id_contribuyente==undefined || id_contribuyente=='' || id_inmueble=='' || id_inmueble==undefined ||id_frecuencia==undefined || id_frecuencia==''){		
		var typeinfo='Warning';
		var msg='Falta Seleccionar Contribuyente, Inmueble o Frecuencia!';
		display_notify(typeinfo,msg); 
		verificar1=false;		
	}
	else{
		verificar1=true;
	}
	
	if (total==undefined || total==''|| total==0){		
		var typeinfo='Warning';
		var msg='Falta Seleccionar Cuentas para Cobro de Servicios!';
		display_notify(typeinfo,msg); 
		verifica2=false;			
	}
	else{
		verificar2=true;
	}
	if (id_cuenta==undefined){
		id_cuenta=0
		}	
    var dataString ='process='+process+'&id_contribuyente='+id_contribuyente+'&id_inmueble='+id_inmueble;
	dataString+='&id_cuenta='+id_cuenta+'&total='+total+'&fiesta='+fiesta+'&frecuencia='+id_frecuencia ;
	//uso un script para capturar los valores de la tabla 
	var TableData = storeTblValues();
	dataString+="&stringdatos=" + TableData
	//alert(dataString)
	if (verificar1==true && verificar2==true){
		$.ajax({
            type: "POST",
            url: url1,
            data: dataString,
            dataType : 'json',
            success: function(data){	
					process=data.process;
					display_notify(data.typeinfo,data.msg,data.process);	
					setInterval("reload1();", 5000);				
				}
        });
	}		          
}
//Funcion para recorrer la tabla completa y pasar los valores de los elementos a un array
function storeTblValues(){
    var TableData = new Array();
    var i=0;
    var td1;var td2;var td3;var td4;var td5;var td6;
	var StringDatos='';
	$("#accountable>tbody  tr").each(function (index) {
		 if (index>=0){			
           var campo0,campo1, campo2, campo3, campo4, campo5,campo6,campo7;
            $(this).children("td").each(function (index2) {
                switch (index2){
                    case 0: 
						campo1= $(this).text();						
                        break;                   
                    case 1: 
						campo2 = $(this).text();					
                        break;
                    case 3: 
						campo3 = $(this).text();	
						campo4= $(this).find("#valor").val()  				
                        break;
                    case 4: 
						campo5= $(this).find("#cant").val();                        			
                        break;            
                    case 5: 						
                       campo6=  $(this).text();             
                        break; 
                }                	
            });
            if(campo1!=""|| campo1!=undefined || isNaN(campo1)==false ){
				StringDatos+=campo1+"|"+campo2+"|"+campo3+"|"+campo4+"|"+campo5+"|"+campo6+"#";
				i=i+1;  
			}	
          } 
        });
	/*
    $('#accountable tr').each(function(row, tr){
		td1=$(tr).find('td:eq(0)').text();
        td2=$(tr).find('td:eq(1)').text();
        td3=$(tr).find('td:eq(3)').text();
        td4=$(tr).find('td:eq(3)').find("#valor").val()
        td5=$(tr).find('td:eq(4)').find("#cant").val()
        td6=$(tr).find('td:eq(5)').text();
               
        if(row>0 || td5!=undefined || td4!=undefined || td4!=""  || td5!=""){
			StringDatos+=td1+"|"+td2+"|"+td3+"|"+td4+"|"+td5+"|"+td6+"#";
			i=i+1;
		}  
    }); 
    */
   StringDatos+="&cuantos="+i
   return StringDatos;
}
