<?php
include("_core.php");
$sql_empresa=_query("SELECT * FROM municipalidad,municipio WHERE municipalidad.id_municipio=municipio.id_municipio ");

	$texto_bienvenida_encabezado=" Usuario";
?>
<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                            <img alt="image" class="logo" id='logo_menu' src="logo.jpeg ">
                             </span>

                    </div>
                    <div class="logo-element">
                    </div>
                </li>
								<li class='active'>
							<a href='dashboard.php' class='text-success'><i class='fa fa-star-o'></i> <span class='nav-label'>Inicio</span></a>
							</li>
								</li>
								<li>
									<div>
												<img alt="image" class="logo" id='logo_menu2' src="yun.jpeg ">
										</div>
								</li>
</ul>
        </div>
    </nav>
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            <form role="search" class="navbar-form-custom" action="search_results.html">
                <div class="form-group">
                          </div>
            </form>
        </div>

            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message"><b>Bienvenid@</b> <b><?php echo $_SESSION["nombre"]; ?> </b></span>
                </li>

                <li>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Salir
                    </a>
                </li>
								<li>

                </li>
            </ul>

        </nav>
        </div>

		<div class='modal fade' id='viewModal' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
			<div class='modal-dialog'>
				<div class='modal-content'></div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
