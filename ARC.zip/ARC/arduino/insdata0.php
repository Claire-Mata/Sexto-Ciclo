<?php
//crear un directorio en /var/www/html/arduino donde van los script php connect.php e insdata.php
//  el sketch es sktemp
// en el sketch se define la ip o el dominio del servidor remoto
error_reporting(E_ALL);
ini_set('display_errors', '1');
date_default_timezone_set('America/El_Salvador');
include ("connect.php");
$conexion = mysqli_connect ($host, $usuario, $clave, $db) or die ("No se encuentra el servidor");

$fecha=date('Y-m-d');
$hora=date('H:i:s');
$valor=0.0;
$distancia=0.0;
$temperatura=0.0;
$tempamb=0.0;
if (isset($_POST['distancia'])) {
	$distancia = $_POST['distancia'];
}
if (isset($_POST['temperatura'])) {
	$temperatura = $_POST['temperatura'];
}
if (isset($_POST['tempamb'])) {
	$tempamb = $_POST['tempamb'];
}

$q="INSERT INTO  `temp`(`id`, `fecha`,`hora`, `distancia`, `temperatura`,`tempamb`) VALUES ('','$fecha','$hora','$distancia','$temperatura','$tempamb')";
mysqli_query($conexion,$q) or die ("--Error en la base de datos");
mysqli_close($conexion);
?>
