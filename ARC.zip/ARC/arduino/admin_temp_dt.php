<?php
	include ("_core.php");

	$requestData= $_REQUEST;
	$fechai= $_REQUEST['fechai'];
	$fechaf= $_REQUEST['fechaf'];

	require('ssp.customized.class.php' );
	// DB tabla a usar
	$table = 'temp';
	// Table's primary key
	$primaryKey = 'id';

	// MySQL server connection information
	$sql_details = array(
  'user' => $user,
  'pass' => $password,
  'db'   => $db,
  'host' => $host
  );

	$id_user=$_SESSION["id_usuario"];
	$joinQuery = "	FROM  temp AS t	";
	$extraWhere = "t.fecha BETWEEN '$fechai' AND '$fechaf' ";
	$columns = array(
	array( 'db' => '`t`.`id`', 'dt' => 0, 'field' => 'id' ),
	array( 'db' => '`t`.`fecha`', 'dt' =>1, 'field' => 'fecha' ),
	array( 'db' => '`t`.`hora`', 'dt' =>2, 'field' => 'hora' ),
	array( 'db' => '`t`.`distancia`', 'dt' =>3, 'field' => 'distancia' ),
	array( 'db' => '`t`.`temperatura`', 'dt' =>4, 'field' => 'temperatura' ),
	array( 'db' => '`t`.`tempamb`', 'dt' =>5, 'field' => 'tempamb' ),
	);
	echo json_encode(
		SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere )
	);
?>



