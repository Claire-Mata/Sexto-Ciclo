<?php
include_once "_core.php";
$_PAGE = array();
$_PAGE['title'] = 'Dashboard';
$_PAGE['links'] = null;
include ("header2.php");
include ("header.php");
include ("menu.php");
$id_user=$_SESSION["id_usuario"];
?>

  <div class="row">
    <div class="col-lg-12">
      <div class="wrapper wrapper-content" id="dash">
        <div class="row">
          <div class="col-lg-3">
            <a href="admin_temp.php">
              <div class="ibox float-e-margins">
                <div class="ibox-title">
                  <span class="label label-warning pull-right">VER TEMPERATURAS</span>
                  <i class="fa fa-group fa-3x"></i>
                </div>
                <div class="ibox-content">
                  <h3 class="no-margins"> POR FECHA</h3>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-3">
            <a href="admin_est.php">
              <div class="ibox float-e-margins">
                <div class="ibox-title">
                  <span class="label label-warning pull-right">VER</span>
                  <i class="fa fa-home fa-3x"></i>
                </div>
                <div class="ibox-content">
                  <h3 class="no-margins">ESTADISTICAS </h3>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-3">
            <a href="logout.php">
              <div class="ibox float-e-margins">
                <div class="ibox-title">
                  <span class="label label-warning pull-right">SALIR</span>
                  <i class="fa fa-sign-out fa-3x"></i>
                </div>
                <div class="ibox-content">
                  <h3 class="no-margins">&nbsp;</h3>
                </div>
              </div>
            </a>
          </div>

        </div>

      </div>


    </div>
  <?php
include("footer.php");
